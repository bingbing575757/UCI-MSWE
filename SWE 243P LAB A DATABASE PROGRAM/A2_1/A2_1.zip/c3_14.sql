SELECT 
    50000 AS starting_principal,
    50000 * 0.065 AS interest,
    50000 + (50000 * 0.065) AS principal_plus_interest;
 