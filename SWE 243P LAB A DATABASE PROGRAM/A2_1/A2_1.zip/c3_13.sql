SELECT 
    DATE_FORMAT(CURRENT_DATE(), '%m-%d-%Y') AS 'current_date';